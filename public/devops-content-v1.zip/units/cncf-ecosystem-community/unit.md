# CNCF ecosystem, projects, standards, and community

Kubernetes is one project in a much larger cloud-native ecosystem. KCNA expects you to recognize common responsibilities, not memorize every logo in the CNCF Landscape.

## Learn projects by job

Representative examples:

| Need | Example project or interface | Mental model |
| --- | --- | --- |
| Container runtime | containerd | Runs containers beneath higher-level orchestration |
| Cluster DNS | CoreDNS | Resolves service/workload names using pluggable DNS behavior |
| Metrics monitoring | Prometheus | Scrapes/stores/query labeled time-series metrics and evaluates alert rules |
| Telemetry instrumentation | OpenTelemetry | Vendor-neutral APIs, SDKs, semantic conventions, and Collector |
| Proxy/data plane | Envoy | L4/L7 proxy often used by gateways and service meshes |
| Logging pipeline | Fluentd | Collects and routes log/event data |
| Package management | Helm | Templates and packages Kubernetes resources as charts |
| GitOps delivery | Flux / Argo CD | Reconciles version-controlled desired state into a target platform |

The table is a responsibility map, not a required architecture. You can run Kubernetes without using every listed project.

## Landscape is a catalog, not a product prescription

The CNCF Landscape organizes a very large ecosystem of projects and products. Inclusion in the landscape does not mean CNCF requires or endorses every item as part of one standard stack.

For exam questions, identify the category first: runtime, networking, observability, delivery, storage, security, service mesh, or another responsibility. Then recognize representative tools.

## Project maturity and governance

CNCF-hosted projects can move through maturity levels such as Sandbox, Incubating, and Graduated according to CNCF governance and project criteria. Maturity indicates project status within CNCF; it does not mean a Sandbox project is automatically unsafe or a Graduated project fits every use case.

The CNCF Technical Oversight Committee and project maintainers participate in project governance. Kubernetes itself has a large community structure with Special Interest Groups (SIGs), Working Groups, and other contributor roles that divide ownership by technical area.

## Open interfaces reduce hard coupling

Cloud-native systems benefit from stable interfaces between responsibilities. Examples include:

- OCI image/runtime specifications for container artifacts and runtime behavior;
- CRI between kubelet and container runtimes;
- CNI conventions for container/Pod network integration;
- CSI for storage integration.

These boundaries allow implementations to evolve behind a known contract. Do not confuse an interface with one implementation: CNI is not itself a single network plugin, and CSI is not a storage backend.

## SIGs own areas; KEPs explain proposed changes

A Kubernetes **Special Interest Group (SIG)** brings contributors together
around an area such as networking, storage, authentication, or autoscaling.
A Working Group can coordinate a cross-cutting effort. These are collaboration
and ownership structures, not processes that run on a worker node.

A **Kubernetes Enhancement Proposal (KEP)** records the motivation, design,
risks, testing, and graduation expectations for a significant change. A proposal
can be discussed or approved before a feature is shipped or enabled. Track its
release status and relevant feature gates in the version you operate; finding
a KEP is not proof that your cluster implements it.

Open standards and open-source projects also differ. OCI specifications define
container image/runtime contracts; containerd is an implementation. CNI defines
network integration conventions; a chosen plugin implements them. Shared
interfaces reduce integration coupling, but replaceability still requires
compatible versions, semantics, configuration, and operational support.

## Community collaboration is part of the architecture story

Open governance matters because cloud-native infrastructure is built by many organizations that need shared specifications, interoperable implementations, documented ownership, and public technical decision processes.

When you encounter an unfamiliar project, ask three questions:

1. What responsibility does it own?
2. Which interface or control/data-plane boundary does it implement?
3. Is it an implementation, a specification, a hosted project, or a catalog entry?

That method is more durable than memorizing the visual layout of the CNCF Landscape.

## Worked case: route the technical question to its owner

~~~text
need: Pod networking compatible with kubelet/runtime integration
contract: CNI conventions; implementation: selected network plugin/dataplane
need: container process execution
contract: CRI; implementation: containerd via its CRI integration
question: Kubernetes networking integration → SIG Network + relevant project
~~~

This authored map explains ownership without prescribing a complete stack.
A reproducible bug report should name versions, the interface call or object,
expected behavior and the smallest observed failure. A Kubernetes integration
issue and a plugin-internal forwarding defect may have different owners; start
with the responsible project's documented reporting process.

CNCF hosts projects and supports an ecosystem; it does not become the runtime
executor or require every listed product. Open contracts make replacement and
collaboration possible, but two implementations still need compatible versions
and configuration before interoperability is demonstrated.
